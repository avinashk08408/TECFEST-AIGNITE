export interface ChronicleEntry {
  year: string;
  hall: string;
  record: string;
  detail: string;
  mark: ' present' | 'milestone' | 'foundation';
}

export const chronicles: ChronicleEntry[] = [
  {
    year: '2025 — PRESENT',
    hall: 'SRM VALLIAMMAI ENGINEERING COLLEGE, CHENNAI',
    record: 'B.E. Cyber Security — undergraduate engineer',
    detail:
      'Foundations in computing, networks and security doctrine. Coursework across C, Python, systems and web technologies, with lab work in Linux, networking and OWASP-aligned testing.',
    mark: ' present',
  },
  {
    year: '2025',
    hall: 'THE FORGE IGNITES',
    record: 'AuthShield + Web Vulnerability Scanner',
    detail:
      'First security builds: a hardened authentication service with monitoring, and an authorized-target scanner that audits own projects for OWASP basics.',
    mark: 'milestone',
  },
  {
    year: '2025 — 2026',
    hall: 'THE ENGINEERING WING',
    record: 'Shock P&L Engine + Weather CLI + PQC Proxy concept',
    detail:
      'Expanded from security into systems engineering: deterministic portfolio stress-testing, a terminal weather instrument, and a post-quantum proxy migration design.',
    mark: 'milestone',
  },
  {
    year: 'BEFORE THE GATE',
    hall: 'FOUNDATIONS',
    record: 'C · Python · Web fundamentals',
    detail:
      'Self-driven groundwork in programming and web structure that made the fortress builds possible — problem solving through small, shipped experiments.',
    mark: 'foundation',
  },
];

export interface ArchiveRecord {
  name: string;
  issuer: string;
  date: string;
  status: string;
  note: string;
  link?: string;
}

export const archiveRecords: ArchiveRecord[] = [
  {
    name: 'B.E. CYBER SECURITY — IN PROGRESS',
    issuer: 'SRM Valliammai Engineering College',
    date: '2025 — Present',
    status: 'ACTIVE RECORD',
    note: 'Degree record. Coursework and lab work form the verified foundation of this archive.',
  },
  {
    name: 'SECURITY LAB PRACTICE — CONTINUOUS',
    issuer: 'Self-directed · authorized targets only',
    date: 'Ongoing',
    status: 'FIELD LOG',
    note: 'Hands-on work with Linux, Nmap, Burp Suite and OWASP methodology inside lab environments. No third-party targets.',
  },
  {
    name: 'FORMAL CERTIFICATIONS — PENDING INSCRIPTION',
    issuer: 'To be issued',
    date: 'Forthcoming',
    status: 'SEALED',
    note: 'No third-party certificates are claimed here. Future credentials will be inscribed with issuer, date and verifiable link.',
  },
];
