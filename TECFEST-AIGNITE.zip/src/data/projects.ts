export interface ForgeDiagram {
  steps: string[];
  note?: string;
}

export interface ForgeProject {
  id: string;
  fileNo: string;
  name: string;
  epithet: string;
  status: 'OPERATIONAL' | 'FIELD-TESTED' | 'CONCEPT' | 'ACTIVE';
  problem: string;
  approach: string;
  architecture: string[];
  diagram?: ForgeDiagram;
  tech: string[];
  features: string[];
  challenges: string;
  outcome: string;
  github: string;
  demo?: string;
  seal: string;
}

const GH = 'https://github.com/avinashk08408';

export const projects: ForgeProject[] = [
  {
    id: 'authshield',
    fileNo: 'AVK-FORGE-001',
    name: 'AUTHSHIELD',
    epithet: 'Authentication & security monitoring gate',
    status: 'OPERATIONAL',
    problem:
      'Small web apps ship login forms with no visibility: weak passwords accepted, no brute-force resistance, no audit trail of who tried what.',
    approach:
      'Built a hardened authentication service with layered checks — input validation, password-strength policy, rate-limited login attempts, session handling and a monitoring log that flags suspicious patterns.',
    architecture: ['Client form', 'Validation layer', 'Auth core (hash + session)', 'Rate limiter', 'Security event log'],
    diagram: {
      steps: ['LOGIN REQUEST', 'VALIDATE + SANITIZE', 'VERIFY HASH', 'RATE-LIMIT CHECK', 'SESSION ISSUE', 'LOG EVENT'],
      note: 'Every rejected attempt is recorded as a security event, not silently dropped.',
    },
    tech: ['Python', 'SQL', 'HTML', 'CSS', 'JavaScript'],
    features: ['Secure password hashing', 'Login attempt throttling', 'Strength policy enforcement', 'Suspicious-activity event log', 'Session management'],
    challenges: 'Balancing strict lockout rules against locking out legitimate users; solved with graduated delays instead of hard locks.',
    outcome: 'A reusable auth module with visible attack resistance that can be dropped into future web projects.',
    github: GH,
    seal: 'I',
  },
  {
    id: 'vuln-scanner',
    fileNo: 'AVK-FORGE-002',
    name: 'WEB VULNERABILITY SCANNER',
    epithet: 'Security-focused web testing instrument',
    status: 'FIELD-TESTED',
    problem:
      'Developers deploy sites without knowing their most basic exposures — missing headers, reflected input, common misconfigurations.',
    approach:
      'Built a scanner that crawls target pages it is authorized to test, probes for OWASP-aligned basics (XSS reflections, SQL-error fingerprints, missing security headers, open methods), and emits a ranked findings report.',
    architecture: ['Target intake', 'Crawler', 'Probe engine', 'OWASP rule pack', 'Report generator'],
    diagram: {
      steps: ['TARGET (AUTHORIZED)', 'CRAWL ROUTES', 'PROBE INPUTS', 'MATCH OWASP RULES', 'RANK FINDINGS', 'REPORT'],
      note: 'Designed for authorized testing of own projects and labs only.',
    },
    tech: ['Python', 'Networking', 'OWASP', 'Linux'],
    features: ['Authorized-target crawling', 'XSS / SQLi signature probes', 'Security-header audit', 'Severity-ranked report', 'Safe, non-destructive checks'],
    challenges: 'Avoiding aggressive requests that could harm targets; solved with throttled, read-only probes and explicit scope control.',
    outcome: 'Used to audit personal web projects before deployment; caught missing headers and unsanitized reflections early.',
    github: GH,
    seal: 'II',
  },
  {
    id: 'shock-pnl',
    fileNo: 'AVK-FORGE-003',
    name: 'SHOCK P&L ENGINE',
    epithet: 'Portfolio stress-testing & shock-analysis engine',
    status: 'OPERATIONAL',
    problem:
      'A portfolio that looks profitable in calm markets can collapse under shocks — investors need to see what breaks, where, and by how much.',
    approach:
      'Built a deterministic engine: load holdings from CSV, reprice positions under configurable market shocks (index crash, rate spike, sector drawdown), attribute P&L per position and scenario, and render comparison tables.',
    architecture: ['CSV ledger', 'Portfolio engine', 'Shock engine', 'Market scenarios', 'P&L attribution', 'Results'],
    diagram: {
      steps: ['CSV', 'PORTFOLIO ENGINE', 'SHOCK ENGINE', 'MARKET SCENARIOS', 'P&L ATTRIBUTION', 'RESULTS'],
      note: 'Pure functions: same CSV + same shocks = identical report, every run.',
    },
    tech: ['Python', 'SQL', 'Git'],
    features: ['CSV portfolio ingestion', 'Configurable shock scenarios', 'Per-position P&L attribution', 'Scenario comparison tables', 'Deterministic, auditable runs'],
    challenges: 'Keeping attribution exact under overlapping shocks; solved by isolating scenario math into independent, testable transforms.',
    outcome: 'Turns a static holdings file into a decision-grade stress report in seconds.',
    github: GH,
    seal: 'III',
  },
  {
    id: 'weather-cli',
    fileNo: 'AVK-FORGE-004',
    name: 'WEATHER FORECAST CLI',
    epithet: 'Python API-driven command terminal',
    status: 'OPERATIONAL',
    problem: 'Checking forecasts in a browser breaks developer flow; CLI users need instant weather without leaving the terminal.',
    approach:
      'Built a Python CLI that queries a weather API, caches responses, handles invalid cities and network failures gracefully, and prints compact, readable forecasts with flags for units and detail level.',
    architecture: ['CLI parser', 'API client', 'Cache', 'Formatter'],
    diagram: {
      steps: ['CITY INPUT', 'CACHE CHECK', 'API FETCH', 'PARSE + FORMAT', 'TERMINAL RENDER'],
    },
    tech: ['Python', 'Git'],
    features: ['City search + flags', 'Current + forecast views', 'Response caching', 'Graceful offline errors', 'Clean terminal tables'],
    challenges: 'Flaky networks and ambiguous city names; solved with explicit error states and disambiguation prompts.',
    outcome: 'A daily-use terminal tool demonstrating API integration, caching and UX writing for CLIs.',
    github: GH,
    seal: 'IV',
  },
  {
    id: 'pqc-proxy',
    fileNo: 'AVK-FORGE-005',
    name: 'PQC DYNAMIC PROXY ENGINE',
    epithet: 'Post-quantum security proxy concept',
    status: 'CONCEPT',
    problem:
      'Classical key exchange will not survive large-scale quantum decryption — proxies that only speak RSA/ECDH need a migration path.',
    approach:
      'Designed a forward-proxy concept with hybrid handshakes (classical + post-quantum KEM), crypto-agility (algorithm negotiation per route), and a policy engine that upgrades connections where PQC is available and logs where it is not.',
    architecture: ['Client edge', 'Policy engine', 'Hybrid handshake (ECDH + KEM)', 'Upstream pool', 'Readiness ledger'],
    diagram: {
      steps: ['CLIENT HELLO', 'POLICY CHECK', 'HYBRID HANDSHAKE', 'UPSTREAM RELAY', 'READINESS LOG'],
      note: 'Research concept: architecture and negotiation flow validated; full PQC lib integration is the next milestone.',
    },
    tech: ['Go', 'Networking', 'Linux', 'Web Security'],
    features: ['Hybrid key-exchange design', 'Per-route crypto policy', 'PQC-readiness ledger', 'Graceful classical fallback', 'Lab-benchmark harness plan'],
    challenges: 'PQC keys are large and slow; the design isolates negotiation so algorithms can be swapped without rewriting relay logic.',
    outcome: 'A clear migration blueprint from classical-only proxying to quantum-resilient transport.',
    github: GH,
    seal: 'V',
  },
];
