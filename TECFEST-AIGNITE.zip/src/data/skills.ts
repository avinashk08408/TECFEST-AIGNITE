export interface ArmoryTool {
  name: string;
  context: string;
  use: string;
  linked: string[];
}

export interface ArmoryCategory {
  id: string;
  title: string;
  inscription: string;
  tools: ArmoryTool[];
}

export const armory: ArmoryCategory[] = [
  {
    id: 'web',
    title: 'WEB ENGINEERING',
    inscription: 'Instruments for building interfaces that hold under siege.',
    tools: [
      { name: 'HTML', context: 'Semantic structure in every project', use: 'Accessible, SEO-clean document architecture', linked: ['AuthShield', 'Shock P&L Engine'] },
      { name: 'CSS', context: 'Custom design systems, no templates', use: 'Fortress-grade visual language & responsive layouts', linked: ['AuthShield', 'This fortress'] },
      { name: 'JavaScript', context: 'Interactive client logic', use: 'State, validation, inspection interfaces', linked: ['AuthShield', 'Vulnerability Scanner'] },
      { name: 'React', context: 'This portfolio & component systems', use: 'Data-driven UI: Forge, Armory, Chronicles', linked: ['This fortress'] },
    ],
  },
  {
    id: 'dev',
    title: 'DEVELOPMENT',
    inscription: 'Heavy machinery for logic, data and transport.',
    tools: [
      { name: 'Python', context: 'Primary engineering language', use: 'Auth, scanners, engines, CLIs, automation', linked: ['AuthShield', 'Vuln Scanner', 'Shock P&L', 'Weather CLI'] },
      { name: 'C', context: 'Systems foundations coursework', use: 'Memory, pointers, low-level reasoning', linked: ['Course labs'] },
      { name: 'C++', context: 'DSA & performance practice', use: 'Algorithms, problem solving', linked: ['Course labs'] },
      { name: 'Java', context: 'OOP & coursework builds', use: 'Structured application design', linked: ['Course labs'] },
      { name: 'Go', context: 'Proxy & network concepts', use: 'Concurrent services, PQC proxy design', linked: ['PQC Proxy Engine'] },
      { name: 'SQL', context: 'Auth & portfolio data stores', use: 'Schema design, queries, attribution records', linked: ['AuthShield', 'Shock P&L'] },
      { name: 'Git', context: 'Every build versioned', use: 'Branching, history, safe experimentation', linked: ['All forge works'] },
      { name: 'GitHub', context: 'avinashk08408 — public record', use: 'Source of truth, Pages deployment', linked: ['All forge works'] },
    ],
  },
  {
    id: 'sec',
    title: 'SECURITY',
    inscription: 'Wards and lenses for seeing attacks before they land.',
    tools: [
      { name: 'Linux', context: 'Daily lab environment', use: 'Terminal ops, permissions, services', linked: ['Vuln Scanner', 'Weather CLI'] },
      { name: 'Networking', context: 'Core of proxy & scanner work', use: 'HTTP, DNS, sockets, relays', linked: ['PQC Proxy', 'Vuln Scanner'] },
      { name: 'OWASP', context: 'Guiding doctrine for testing', use: 'Top-10 aligned checks & fixes', linked: ['Vuln Scanner', 'AuthShield'] },
      { name: 'Burp Suite', context: 'Hands-on interception labs', use: 'Proxying, repeater, request analysis', linked: ['Vuln Scanner'] },
      { name: 'Nmap', context: 'Network reconnaissance labs', use: 'Host & service discovery on own lab targets', linked: ['Vuln Scanner'] },
      { name: 'Web Security', context: 'Headers, hashing, sessions', use: 'Hardening every shipped interface', linked: ['AuthShield'] },
    ],
  },
];
