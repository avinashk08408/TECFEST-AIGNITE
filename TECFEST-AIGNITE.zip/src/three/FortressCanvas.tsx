import { Suspense, lazy, useEffect, useMemo, useRef, useState } from 'react';

const LazyScene = lazy(() => import('./FortressScene'));

function isMobileWidth() {
  return typeof window !== 'undefined' && window.matchMedia('(max-width: 760px)').matches;
}

export function CssFortressFallback({ label = 'Fortress vista' }: { label?: string }) {
  return (
    <div className="fort-fallback" role="img" aria-label={label}>
      <div className="fort-fallback__moon" />
      <div className="fort-fallback__mtn m1" />
      <div className="fort-fallback__mtn m2" />
      <div className="fort-fallback__mtn m3" />
      <div className="fort-fallback__keep">
        <div className="fort-fallback__tower left" />
        <div className="fort-fallback__tower right" />
        <div className="fort-fallback__center">
          <span /><span className="lit" /><span />
          <span className="lit" /><span className="lit core" /><span className="lit" />
          <span /><span className="lit" /><span />
        </div>
      </div>
      <div className="fort-fallback__fog f1" />
      <div className="fort-fallback__fog f2" />
      <div className="fort-fallback__ground" />
    </div>
  );
}

export default function FortressCanvas() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [webgl, setWebgl] = useState(true);
  const [reduced, setReduced] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [visible, setVisible] = useState(true);
  const [scroll, setScroll] = useState(0);
  const mouse = useRef({ x: 0, y: 0 });
  const shared = useMemo(() => ({ mouse: mouse.current, scroll: 0, reduced: false }), []);

  useEffect(() => {
    try {
      const c = document.createElement('canvas');
      setWebgl(!!(c.getContext('webgl') || c.getContext('experimental-webgl')));
    } catch {
      setWebgl(false);
    }
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReduced(mq.matches);
    const onMq = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener?.('change', onMq);
    const onResize = () => setMobile(isMobileWidth());
    onResize();
    window.addEventListener('resize', onResize, { passive: true });
    return () => {
      mq.removeEventListener?.('change', onMq);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  useEffect(() => {
    shared.reduced = reduced;
  }, [reduced, shared]);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const h = document.documentElement.scrollHeight - window.innerHeight;
        const p = h > 0 ? window.scrollY / h : 0;
        setScroll(p);
        shared.scroll = p;
      });
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(raf);
    };
  }, [shared]);

  useEffect(() => {
    if (reduced) return;
    const onMove = (e: PointerEvent) => {
      const nx = (e.clientX / window.innerWidth) * 2 - 1;
      const ny = -((e.clientY / window.innerHeight) * 2 - 1);
      mouse.current.x += (nx - mouse.current.x) * 0.08;
      mouse.current.y += (ny - mouse.current.y) * 0.08;
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    return () => window.removeEventListener('pointermove', onMove);
  }, [reduced]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el || !('IntersectionObserver' in window)) return;
    const io = new IntersectionObserver(([en]) => setVisible(en.isIntersecting), { threshold: 0.02 });
    io.observe(el);
    const onHide = () => {
      if (document.hidden) setVisible(false);
      else {
        const r = el.getBoundingClientRect();
        setVisible(r.bottom > 0 && r.top < window.innerHeight);
      }
    };
    document.addEventListener('visibilitychange', onHide);
    return () => {
      io.disconnect();
      document.removeEventListener('visibilitychange', onHide);
    };
  }, []);

  const simplified = mobile;
  const showStatic = !webgl || reduced;

  return (
    <div ref={wrapRef} className="fort-canvas" aria-hidden="true">
      {showStatic ? (
        <CssFortressFallback />
      ) : visible ? (
        <Suspense fallback={<CssFortressFallback label="Fortress materializing" />}>
          <LazyScene shared={shared} simplified={simplified} />
        </Suspense>
      ) : (
        <CssFortressFallback label="Fortress resting" />
      )}
      <div className="fort-canvas__vignette" />
      <div className="fort-canvas__grain" />
      {/* scroll-linked veil so the world "evolves" without trapping content */}
      <div className="fort-canvas__veil" style={{ opacity: 0.25 + scroll * 0.45 }} />
    </div>
  );
}
