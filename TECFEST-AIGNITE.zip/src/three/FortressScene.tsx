import { useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface RigState {
  mouse: { x: number; y: number };
  scroll: number;
  reduced: boolean;
}

/* ---------------------------------- rig ---------------------------------- */

function CameraRig({ shared, simplified }: { shared: RigState; simplified: boolean }) {
  useFrame((state, delta) => {
    if (shared.reduced) return;
    const t = Math.min(1, Math.max(0, shared.scroll));
    const mx = simplified ? shared.mouse.x * 0.35 : shared.mouse.x;
    const my = simplified ? shared.mouse.y * 0.25 : shared.mouse.y;
    const cam = state.camera;
    const tx = mx * 2.2;
    const ty = 4.6 + t * 2.4 + my * 0.9;
    const tz = 27 - t * 9;
    const k = 1 - Math.exp(-delta * 1.6);
    cam.position.x += (tx - cam.position.x) * k;
    cam.position.y += (ty - cam.position.y) * k;
    cam.position.z += (tz - cam.position.z) * k;
    cam.lookAt(0, 4.2 + t * 1.2, 0);
  });
  return null;
}

function EnergyCore({ position, scale = 1, speed = 1 }: { position: [number, number, number]; scale?: number; speed?: number }) {
  const ref = useRef<THREE.Mesh>(null);
  const glow = useRef<THREE.PointLight>(null);
  useFrame((state) => {
    const t = state.clock.elapsedTime * speed;
    if (ref.current) {
      ref.current.rotation.y = t * 0.6;
      ref.current.rotation.x = Math.sin(t * 0.5) * 0.25;
      const s = scale * (1 + Math.sin(t * 2) * 0.06);
      ref.current.scale.setScalar(s);
    }
    if (glow.current) glow.current.intensity = 14 + Math.sin(t * 2) * 4;
  });
  return (
    <group position={position}>
      <mesh ref={ref}>
        <octahedronGeometry args={[0.55, 0]} />
        <meshStandardMaterial color="#0e2b1d" emissive="#2bd97c" emissiveIntensity={2.2} roughness={0.25} metalness={0.1} />
      </mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.95 * scale, 0.045, 8, 40]} />
        <meshStandardMaterial color="#3a3f3a" emissive="#2bd97c" emissiveIntensity={0.5} roughness={0.4} metalness={0.85} />
      </mesh>
      <pointLight ref={glow} color="#2bd97c" intensity={14} distance={11} decay={2} />
    </group>
  );
}

function Tower({ position, height = 9, radius = 1.15 }: { position: [number, number, number]; height?: number; radius?: number }) {
  return (
    <group position={position}>
      <mesh position={[0, height / 2, 0]}>
        <cylinderGeometry args={[radius * 0.92, radius * 1.12, height, 7]} />
        <meshStandardMaterial color="#23262b" roughness={0.85} metalness={0.35} flatShading />
      </mesh>
      {/* battlements */}
      {Array.from({ length: 7 }).map((_, i) => {
        const a = (i / 7) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * radius * 0.9, height + 0.28, Math.sin(a) * radius * 0.9]}>
            <boxGeometry args={[0.34, 0.55, 0.34]} />
            <meshStandardMaterial color="#2b2e34" roughness={0.9} metalness={0.3} />
          </mesh>
        );
      })}
      <mesh position={[0, height + 1.5, 0]}>
        <coneGeometry args={[radius * 1.02, 2.4, 7]} />
        <meshStandardMaterial color="#17191d" roughness={0.8} metalness={0.4} flatShading />
      </mesh>
      {/* green slit windows */}
      {[0.45, 0.62].map((h, i) => (
        <mesh key={i} position={[0, height * h, radius * 0.96]}>
          <boxGeometry args={[0.16, 0.7, 0.06]} />
          <meshStandardMaterial color="#06120c" emissive="#2bd97c" emissiveIntensity={2.6} />
        </mesh>
      ))}
    </group>
  );
}

function Fortress() {
  return (
    <group position={[0, 0, 0]}>
      {/* main curtain wall */}
      <mesh position={[0, 2.1, -2]}>
        <boxGeometry args={[16, 4.2, 1.4]} />
        <meshStandardMaterial color="#22252a" roughness={0.9} metalness={0.3} />
      </mesh>
      {/* wall crenellation */}
      {Array.from({ length: 13 }).map((_, i) => (
        <mesh key={i} position={[-7.2 + i * 1.2, 4.5, -2]}>
          <boxGeometry args={[0.55, 0.6, 1.1]} />
          <meshStandardMaterial color="#2a2d33" roughness={0.9} metalness={0.3} />
        </mesh>
      ))}
      {/* gate arch */}
      <mesh position={[0, 1.5, -1.25]}>
        <boxGeometry args={[3.2, 3, 0.5]} />
        <meshStandardMaterial color="#0d0f12" roughness={0.9} metalness={0.2} />
      </mesh>
      <mesh position={[0, 1.5, -1.0]}>
        <boxGeometry args={[2.3, 2.4, 0.2]} />
        <meshStandardMaterial color="#071009" emissive="#2bd97c" emissiveIntensity={0.7} roughness={0.6} />
      </mesh>
      {/* gate pillars */}
      {[-2.1, 2.1].map((x, i) => (
        <group key={i} position={[x, 0, -1.2]}>
          <mesh position={[0, 2.6, 0]}>
            <boxGeometry args={[1, 5.2, 1]} />
            <meshStandardMaterial color="#26292f" roughness={0.85} metalness={0.4} />
          </mesh>
          <mesh position={[0, 5.45, 0]}>
            <boxGeometry args={[1.3, 0.5, 1.3]} />
            <meshStandardMaterial color="#3a3325" roughness={0.6} metalness={0.7} />
          </mesh>
          <mesh position={[0, 5.9, 0]}>
            <sphereGeometry args={[0.28, 12, 12]} />
            <meshStandardMaterial color="#0a0f0c" emissive="#e2c477" emissiveIntensity={2.4} />
          </mesh>
        </group>
      ))}
      <Tower position={[-8.2, 0, -2]} height={10} />
      <Tower position={[8.2, 0, -2]} height={10} />
      <Tower position={[-4.4, 0, -4.5]} height={13} radius={1.35} />
      <Tower position={[4.4, 0, -4.5]} height={13} radius={1.35} />
      {/* central keep */}
      <group position={[0, 0, -7]}>
        <mesh position={[0, 5, 0]}>
          <boxGeometry args={[7, 10, 4]} />
          <meshStandardMaterial color="#1f2227" roughness={0.88} metalness={0.32} />
        </mesh>
        <mesh position={[0, 10.6, 0]}>
          <coneGeometry args={[4.6, 3.4, 4]} />
          <meshStandardMaterial color="#14161a" roughness={0.85} metalness={0.4} flatShading />
        </mesh>
        {/* keep window grid — green energy within */}
        {[-1.8, 0, 1.8].map((x, xi) =>
          [3.4, 5, 6.6].map((y, yi) => (
            <mesh key={`${xi}-${yi}`} position={[x, y, 2.02]}>
              <boxGeometry args={[0.9, 1.1, 0.08]} />
              <meshStandardMaterial
                color="#06120c"
                emissive="#2bd97c"
                emissiveIntensity={xi === 1 && yi === 1 ? 3.2 : 1.4}
              />
            </mesh>
          ))
        )}
      </group>
      {/* side energy cores */}
      <EnergyCore position={[-4.4, 13.6, -4.5]} scale={0.9} speed={1} />
      <EnergyCore position={[4.4, 13.6, -4.5]} scale={0.9} speed={1.25} />
      {/* bridge / platform */}
      <mesh position={[0, -0.4, 3.5]} rotation={[-0.06, 0, 0]}>
        <boxGeometry args={[7, 0.5, 12]} />
        <meshStandardMaterial color="#1b1e22" roughness={0.7} metalness={0.6} />
      </mesh>
      {[-3.2, 3.2].map((x, i) => (
        <mesh key={i} position={[x, 0.35, 3.5]}>
          <boxGeometry args={[0.14, 1.1, 11]} />
          <meshStandardMaterial color="#33302a" roughness={0.5} metalness={0.8} />
        </mesh>
      ))}
      {/* industrial pipes along wall */}
      {[-5.6, 5.6].map((x, i) => (
        <mesh key={i} position={[x, 1.2, -1.2]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.22, 0.22, 5.4, 10]} />
          <meshStandardMaterial color="#2e2a22" roughness={0.45} metalness={0.85} />
        </mesh>
      ))}
    </group>
  );
}

function Mountains() {
  const peaks = useMemo(
    () => [
      { p: [-26, -4, -34] as [number, number, number], r: 13, h: 20, c: '#0d1114' },
      { p: [-10, -4, -40] as [number, number, number], r: 16, h: 26, c: '#0b0e11' },
      { p: [8, -4, -42] as [number, number, number], r: 17, h: 28, c: '#0a0d10' },
      { p: [26, -4, -34] as [number, number, number], r: 12, h: 19, c: '#0d1114' },
      { p: [0, -4, -52] as [number, number, number], r: 24, h: 34, c: '#080b0d' },
    ],
    []
  );
  return (
    <group>
      {peaks.map((m, i) => (
        <mesh key={i} position={m.p}>
          <coneGeometry args={[m.r, m.h, 5]} />
          <meshStandardMaterial color={m.c} roughness={1} metalness={0} flatShading />
        </mesh>
      ))}
    </group>
  );
}

function Dust({ count }: { count: number }) {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 44;
      arr[i * 3 + 1] = Math.random() * 16 - 1;
      arr[i * 3 + 2] = Math.random() * 24 - 14;
    }
    return arr;
  }, [count]);
  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.elapsedTime;
    ref.current.position.y = Math.sin(t * 0.18) * 0.5;
    ref.current.rotation.y = t * 0.008;
  });
  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#7de6a8" size={0.055} transparent opacity={0.55} sizeAttenuation depthWrite={false} />
    </points>
  );
}

function EmberSprites({ count }: { count: number }) {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 30;
      arr[i * 3 + 1] = Math.random() * 10;
      arr[i * 3 + 2] = Math.random() * 14 - 4;
    }
    return arr;
  }, [count]);
  useFrame((state, delta) => {
    if (!ref.current) return;
    ref.current.position.y += delta * 0.25;
    if (ref.current.position.y > 3) ref.current.position.y = 0;
  });
  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#e2c477" size={0.05} transparent opacity={0.5} sizeAttenuation depthWrite={false} />
    </points>
  );
}

/* --------------------------------- scene --------------------------------- */

export default function FortressScene({
  shared,
  simplified,
}: {
  shared: RigState;
  simplified: boolean;
}) {
  return (
    <Canvas
      dpr={simplified ? [1, 1.25] : [1, 1.75]}
      gl={{ antialias: !simplified, alpha: false, powerPreference: 'high-performance' }}
      camera={{ position: [0, 4.6, 27], fov: 42, near: 0.1, far: 140 }}
    >
      <color attach="background" args={['#070908']} />
      <fog attach="fog" args={['#070908', 22, 70]} />
      <ambientLight intensity={0.55} color="#9fb3a8" />
      <directionalLight position={[-12, 16, 8]} intensity={1.1} color="#cfd8e6" />
      <directionalLight position={[10, 6, 10]} intensity={0.25} color="#2bd97c" />
      <pointLight position={[0, 3.4, 4]} color="#e2c477" intensity={6} distance={14} decay={2} />
      <CameraRig shared={shared} simplified={simplified} />
      <Mountains />
      <Fortress />
      <Dust count={simplified ? 90 : 320} />
      {!simplified && <EmberSprites count={90} />}
      {/* ground plane */}
      <mesh position={[0, -0.7, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[120, 120]} />
        <meshStandardMaterial color="#0a0c0b" roughness={1} metalness={0} />
      </mesh>
    </Canvas>
  );
}
