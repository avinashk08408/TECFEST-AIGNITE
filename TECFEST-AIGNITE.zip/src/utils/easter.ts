/** Console inscription + hidden archive command. Optional, never required. */
export function inscribeConsole() {
  const style = 'color:#35d07f;background:#0b0e0c;padding:2px 6px;font-weight:bold';
  try {
    console.log('%c AVK // FORTRESS ARCHIVE ', style);
    console.log('%c Engineer: Avinash K — Cyber Security × Web Developer ', 'color:#c8b06a');
    console.log('%c Type fortress("open") to reveal a sealed record. ', 'color:#8b948c');
    (window as unknown as Record<string, unknown>)['fortress'] = (cmd?: string) => {
      if (cmd === 'open') {
        console.log('%c SEALED RECORD: The gate only opens for builders. Keep shipping. — AVK ', style);
        return 'SEALED RECORD: The gate only opens for builders. Keep shipping. — AVK';
      }
      return 'Unknown command. Try fortress("open").';
    };
  } catch {
    /* silent */
  }
}
