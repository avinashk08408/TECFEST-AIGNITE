import { useEffect, useState } from 'react';
import SectionHeading from './SectionHeading';
import { projects, type ForgeProject } from '../data/projects';

function Diagram({ steps, note }: { steps: string[]; note?: string }) {
  return (
    <div className="diagram" role="img" aria-label={`Architecture flow: ${steps.join(' to ')}`}>
      <ol>
        {steps.map((s, i) => (
          <li key={s}>
            <span className="diagram__node">{s}</span>
            {i < steps.length - 1 && <span className="diagram__arrow" aria-hidden="true">▼</span>}
          </li>
        ))}
      </ol>
      {note && <p className="diagram__note">{note}</p>}
    </div>
  );
}

function Inspection({ p, onClose }: { p: ForgeProject; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className="vault" role="dialog" aria-modal="true" aria-label={`${p.name} project file`} onClick={onClose}>
      <div className="vault__door" onClick={(e) => e.stopPropagation()}>
        <div className="vault__head">
          <div>
            <p className="vault__file">PROJECT FILE · {p.fileNo}</p>
            <h3>{p.name}</h3>
            <p className="vault__epithet">{p.epithet}</p>
          </div>
          <div className="vault__meta">
            <span className={`status s-${p.status.toLowerCase().split('-')[0]}`}>{p.status}</span>
            <button className="vault__close" onClick={onClose} aria-label="Close project file">✕ SEAL</button>
          </div>
        </div>
        <div className="vault__body">
          <div className="vault__col">
            <h4>PROBLEM</h4><p>{p.problem}</p>
            <h4>APPROACH</h4><p>{p.approach}</p>
            <h4>CHALLENGES</h4><p>{p.challenges}</p>
            <h4>OUTCOME</h4><p className="vault__outcome">{p.outcome}</p>
          </div>
          <div className="vault__col">
            <h4>ARCHITECTURE</h4>
            {p.diagram ? <Diagram steps={p.diagram.steps} note={p.diagram.note} /> : (
              <ol className="vault__arch">{p.architecture.map((a) => <li key={a}>{a}</li>)}</ol>
            )}
            <h4>TECH STACK</h4>
            <p className="tags">{p.tech.map((t) => <span key={t}>{t}</span>)}</p>
            <h4>KEY FEATURES</h4>
            <ul className="vault__feats">{p.features.map((f) => <li key={f}>{f}</li>)}</ul>
            <div className="vault__actions">
              <a href={p.github} target="_blank" rel="noreferrer" className="btn-iron primary sm"><span>SOURCE</span></a>
              {p.demo && <a href={p.demo} target="_blank" rel="noreferrer" className="btn-iron sm"><span>LIVE DEMO</span></a>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Forge() {
  const [open, setOpen] = useState<ForgeProject | null>(null);
  return (
    <section id="forge" className="chamber" aria-label="The forge — projects">
      <div className="container">
        <SectionHeading
          index="04"
          gate="THE FORGE"
          title="Works hammered into shape"
          sub="Five records. Each opens like an archive drawer — problem, architecture, features, outcome. Nothing decorative survives inspection."
        />
        <div className="forge__grid">
          {projects.map((p, i) => (
            <article key={p.id} className="relic" data-reveal>
              <div className="relic__top">
                <span className="relic__file">{p.fileNo}</span>
                <span className={`status s-${p.status.toLowerCase().split('-')[0]}`}>{p.status}</span>
              </div>
              <div className="relic__seal" aria-hidden="true">{p.seal}</div>
              <h3>{p.name}</h3>
              <p className="relic__epithet">{p.epithet}</p>
              <p className="relic__problem">{p.problem}</p>
              <p className="tags">{p.tech.slice(0, 4).map((t) => <span key={t}>{t}</span>)}</p>
              <div className="relic__actions">
                <button className="btn-iron primary sm" onClick={() => setOpen(p)} aria-haspopup="dialog">
                  <span>INSPECT FILE {String(i + 1).padStart(2, '0')}</span>
                </button>
                <a href={p.github} target="_blank" rel="noreferrer" className="relic__src" aria-label={`${p.name} source on GitHub`}>SOURCE ↗</a>
              </div>
            </article>
          ))}
        </div>
        {open && <Inspection p={open} onClose={() => setOpen(null)} />}
      </div>
    </section>
  );
}
