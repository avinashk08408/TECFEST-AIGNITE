import { useState } from 'react';

const WHISPERS = [
  'ACCESSING THE ARCHIVE',
  'IDENTITY CONFIRMED — BUILDER',
  'THE ARCHIVE KNOWS.',
];

export default function Gate() {
  const [seal, setSeal] = useState(0);
  return (
    <section id="gate" className="gate" aria-label="Fortress gate — introduction">
      <div className="gate__inner">
        <button
          className="gate__emblem"
          onClick={() => setSeal((s) => (s + 1) % WHISPERS.length)}
          aria-label="Mechanical fortress emblem — touch it three times for a sealed whisper"
          title="Touch the seal"
        >
          <svg viewBox="0 0 120 120" width="92" height="92" aria-hidden="true">
            <circle cx="60" cy="60" r="54" fill="none" stroke="#8a6f3c" strokeWidth="2" opacity="0.8" />
            <circle cx="60" cy="60" r="44" fill="none" stroke="#35d07f" strokeWidth="1.2" opacity="0.5" strokeDasharray="6 8" className="spin-slow" />
            <path d="M60 18 L68 30 L82 30 L82 44 L88 47 L88 102 L32 102 L32 47 L38 44 L38 30 L52 30 Z" fill="#0e1310" stroke="#c8b06a" strokeWidth="2" strokeLinejoin="round" />
            <circle cx="60" cy="70" r="11" fill="none" stroke="#35d07f" strokeWidth="2" />
            <circle cx="60" cy="70" r="4" fill="#35d07f" className="pulse-core" />
            <path d="M60 40 L60 52 M48 52 L72 52" stroke="#8a6f3c" strokeWidth="1.6" />
          </svg>
          <span className="gate__whisper" role="status">{WHISPERS[seal]}</span>
        </button>
        <p className="gate__kicker" data-reveal>SRM VALLIAMMAI · CHENNAI · EST. RECORD 2025</p>
        <h1 className="gate__title" data-reveal>
          <span className="gate__name">AVINASH&nbsp;K</span>
          <span className="gate__role">CYBER SECURITY STUDENT <i>&</i> WEB DEVELOPER</span>
        </h1>
        <p className="gate__line" data-reveal>“Engineering secure systems, intelligent interfaces, and digital experiences.”</p>
        <div className="gate__cta" data-reveal>
          <a className="btn-iron primary" href="#architect"><span>ENTER THE FORTRESS</span></a>
          <a className="btn-iron" href="#forge"><span>VIEW THE FORGE</span></a>
        </div>
        <dl className="gate__ledger" data-reveal>
          <div><dt>STATUS</dt><dd className="ledger-online"><i /> SYSTEM ONLINE</dd></div>
          <div><dt>CLEARANCE</dt><dd>BUILDER</dd></div>
          <div><dt>RECORD</dt><dd>github.com/avinashk08408</dd></div>
        </dl>
        <a className="gate__descend" href="#architect" aria-label="Descend into the fortress">
          <span /> DESCEND
        </a>
      </div>
    </section>
  );
}
