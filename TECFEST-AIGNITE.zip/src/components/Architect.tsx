import SectionHeading from './SectionHeading';

const CREED = [
  { k: 'BUILDER', v: 'Ships working systems, not slide decks. Every forge record runs.' },
  { k: 'BREAKER', v: 'Tests own work like an adversary — probes, headers, inputs, sessions.' },
  { k: 'LEARNER', v: 'B.E. Cyber Security undergrad. Labs over lectures; evidence over claims.' },
  { k: 'KEEPER', v: 'Documents architecture so the next engineer can hold the wall.' },
];

export default function Architect() {
  return (
    <section id="architect" className="chamber" aria-label="The architect — about Avinash">
      <div className="container chamber__grid">
        <div>
          <SectionHeading
            index="02"
            gate="THE ARCHITECT'S CHAMBER"
            title="The engineer behind the walls"
            sub="Avinash K — Cyber Security student and web developer at SRM Valliammai Engineering College, Chennai. Not a title collector. A builder."
          />
          <p className="prose" data-reveal>
            I build at the <strong>intersection of software development and cybersecurity</strong>, combining web
            engineering with security-first thinking. Authentication with monitoring, scanners that audit what I
            ship, engines that turn raw data into decisions — sharpened through coursework, OWASP-aligned lab
            practice, and small shipped experiments.
          </p>
          <ul className="creed" data-reveal>
            {CREED.map((c) => (
              <li key={c.k}>
                <span>{c.k}</span>
                <p>{c.v}</p>
              </li>
            ))}
          </ul>
          <div className="architect__facts" data-reveal>
            <div><dt>COLLEGE</dt><dd>SRM Valliammai Engineering College</dd></div>
            <div><dt>PROGRAM</dt><dd>B.E. Cyber Security · 2025 — Present</dd></div>
            <div><dt>BASE</dt><dd>Chennai, India</dd></div>
            <div><dt>PROOF</dt><dd><a href="https://github.com/avinashk08408" target="_blank" rel="noreferrer">github.com/avinashk08408</a></dd></div>
          </div>
          <dl className="vault-stats" data-reveal aria-label="Fortress records">
            <div><dt>05</dt><dd>FORGE RECORDS</dd></div>
            <div><dt>18</dt><dd>TECHNOLOGIES</dd></div>
            <div><dt>03</dt><dd>ARSENAL WINGS</dd></div>
            <div><dt>∞</dt><dd>CURIOSITY</dd></div>
          </dl>
        </div>
        <div className="core-wrap" data-reveal aria-label="Rotating mechanical engineering core — decorative">
          <div className="mech-core">
            <div className="mech-core__ring r1" />
            <div className="mech-core__ring r2" />
            <div className="mech-core__ring r3" />
            <div className="mech-core__heart">
              <span>AVK</span>
              <small>KNOWLEDGE · SECURITY · SYSTEMS</small>
            </div>
            <i className="mech-core__bolt b1" /><i className="mech-core__bolt b2" />
            <i className="mech-core__bolt b3" /><i className="mech-core__bolt b4" />
          </div>
          <p className="core-caption">FIG. 01 — THE ENGINEERING CORE. ROTATION = PRACTICE. CORE = CURIOSITY.</p>
        </div>
      </div>
    </section>
  );
}
