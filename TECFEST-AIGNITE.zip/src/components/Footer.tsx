export default function Footer() {
  return (
    <footer className="foot" aria-label="Fortress footer">
      <div className="container foot__grid">
        <div>
          <p className="foot__brand">AVK <span>//</span> ARCHIVE</p>
          <p className="foot__line">A technological fortress raised by Avinash K — Cyber Security student & Web Developer, SRM Valliammai Engineering College, Chennai.</p>
          <p className="foot__line dim">Original design. No templates. No copied artwork. Stone, iron, emerald.</p>
        </div>
        <nav aria-label="Footer sections">
          <a href="#gate">Gate</a><a href="#architect">Architect</a><a href="#armory">Armory</a><a href="#forge">Forge</a><a href="#chronicles">Chronicles</a><a href="#archive">Archive</a><a href="#contact">Contact</a>
        </nav>
        <div className="foot__seal">
          <p>github.com/avinashk08408</p>
          <p className="dim">© 2026 Avinash K · All walls held</p>
        </div>
      </div>
    </footer>
  );
}
