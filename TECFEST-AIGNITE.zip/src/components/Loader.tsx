import { useEffect, useState } from 'react';

/**
 * Cinematic boot veil. Never blocks content: the fortress renders beneath it,
 * it lifts on window load (or after a short cap), and it is skipped entirely
 * for reduced-motion visitors.
 */
export default function Loader() {
  const [phase, setPhase] = useState<'seal' | 'granted' | 'gone'>('seal');

  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setPhase('gone');
      return;
    }
    let done = false;
    const grant = () => {
      if (done) return;
      done = true;
      setPhase('granted');
      window.setTimeout(() => setPhase('gone'), 520);
    };
    if (document.readyState === 'complete') {
      window.setTimeout(grant, 650);
    } else {
      window.addEventListener('load', () => window.setTimeout(grant, 350), { once: true });
    }
    const cap = window.setTimeout(grant, 2100);
    return () => window.clearTimeout(cap);
  }, []);

  if (phase === 'gone') return null;

  return (
    <div className={`veil${phase === 'granted' ? ' is-granted' : ''}`} role="status" aria-label={phase === 'granted' ? 'Access granted' : 'Initializing archive'}>
      <svg viewBox="0 0 120 120" width="72" height="72" aria-hidden="true" className="veil__sigil">
        <circle cx="60" cy="60" r="54" fill="none" stroke="#8a6f3c" strokeWidth="2" opacity="0.8" />
        <circle cx="60" cy="60" r="44" fill="none" stroke="#35d07f" strokeWidth="1.2" opacity="0.6" strokeDasharray="6 8" className="spin-slow" />
        <path d="M60 18 L68 30 L82 30 L82 44 L88 47 L88 102 L32 102 L32 47 L38 44 L38 30 L52 30 Z" fill="none" stroke="#c8b06a" strokeWidth="2" strokeLinejoin="round" />
        <circle cx="60" cy="70" r="4" fill="#35d07f" className="pulse-core" />
      </svg>
      <p className="veil__text">{phase === 'granted' ? 'ACCESS GRANTED' : 'INITIALIZING ARCHIVE…'}</p>
      <span className="veil__bar" aria-hidden="true"><i /></span>
    </div>
  );
}
