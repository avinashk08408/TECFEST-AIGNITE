export default function SectionHeading({
  index,
  gate,
  title,
  sub,
}: {
  index: string;
  gate: string;
  title: string;
  sub: string;
}) {
  return (
    <div className="sec-head" data-reveal>
      <div className="sec-head__top">
        <span className="sec-head__index">{index}</span>
        <span className="sec-head__rule" />
        <span className="sec-head__gate">{gate}</span>
      </div>
      <h2 className="sec-head__title">{title}</h2>
      <p className="sec-head__sub">{sub}</p>
    </div>
  );
}
