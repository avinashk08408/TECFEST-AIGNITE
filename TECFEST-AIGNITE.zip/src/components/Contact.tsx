import { useState } from 'react';
import SectionHeading from './SectionHeading';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [err, setErr] = useState('');
  const [sent, setSent] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.name.trim().length < 2) return setErr('Inscribe your name — at least 2 characters.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) return setErr('That email sigil is malformed. Check it once more.');
    if (form.message.trim().length < 10) return setErr('The message is too short to cross the walls — 10+ characters.');
    setErr('');
    setSent(true);
    const subject = encodeURIComponent(`FORTRESS TRANSMISSION — ${form.name}`);
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`);
    window.location.href = `mailto:avinashk08408@github.com?subject=${subject}&body=${body}`;
  };

  return (
    <section id="contact" className="chamber chamber--deep" aria-label="Communication chamber — contact">
      <div className="container">
        <SectionHeading
          index="07"
          gate="THE COMMUNICATION CHAMBER"
          title="Open a secure channel"
          sub="A transmission terminal, not a form. Validated at the gate, delivered to the engineer."
        />
        <div className="comm__grid">
          <form className="terminal" onSubmit={submit} noValidate data-reveal aria-label="Secure communication terminal">
            <div className="terminal__bar" aria-hidden="true"><i /><i /><i /><span>AVK-SECURE-LINK · v1.0</span></div>
            <label>NAME<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} name="name" autoComplete="name" placeholder="Your name" required /></label>
            <label>EMAIL<input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} name="email" type="email" autoComplete="email" placeholder="you@domain.com" required /></label>
            <label>MESSAGE<textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} name="message" rows={5} placeholder="State your mission — collaboration, review, opportunity…" required /></label>
            {err && <p className="terminal__err" role="alert">{err}</p>}
            {sent && <p className="terminal__ok" role="status">SEALED. Your mail client carries the transmission — I reply from the fortress.</p>}
            <button className="btn-iron primary" type="submit"><span>TRANSMIT MESSAGE</span></button>
            <p className="terminal__hint">No backend vault yet — transmission routes via your mail client. Nothing is stored in the browser.</p>
          </form>
          <aside className="channels" data-reveal aria-label="Direct channels">
            <h3>DIRECT CHANNELS</h3>
            <a href="https://github.com/avinashk08408" target="_blank" rel="noreferrer"><span>GITHUB</span><small>avinashk08408 · source of truth</small></a>
            <a href="mailto:avinashk08408@github.com"><span>EMAIL</span><small>direct line to the architect</small></a>
            <a href="#archive"><span>IDENTIFICATION FILE</span><small>resume · record AVK-001</small></a>
            <div className="channels__oath">
              <p>“Every message is read inside these walls. If it involves building or breaking — it gets an answer.”</p>
              <small>— AVINASH K, KEEPER OF THE FORGE</small>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
