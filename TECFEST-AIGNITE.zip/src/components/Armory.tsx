import { useState } from 'react';
import SectionHeading from './SectionHeading';
import { armory } from '../data/skills';

export default function Armory() {
  const [cat, setCat] = useState(armory[0].id);
  const [tool, setTool] = useState(armory[0].tools[1].name);
  const active = armory.find((c) => c.id === cat)!;
  const selected = active.tools.find((t) => t.name === tool) ?? active.tools[0];

  return (
    <section id="armory" className="chamber chamber--deep" aria-label="The armory — skills">
      <div className="container">
        <SectionHeading
          index="03"
          gate="THE ARMORY"
          title="Tools of the engineer"
          sub="No percentages. No bars. Each tool is racked with where it was earned and what it defends."
        />
        <div className="armory__racks" role="tablist" aria-label="Skill categories" data-reveal>
          {armory.map((c) => (
            <button
              key={c.id}
              role="tab"
              aria-selected={cat === c.id}
              className={`rack${cat === c.id ? ' is-active' : ''}`}
              onClick={() => {
                setCat(c.id);
                setTool(c.tools[0].name);
              }}
            >
              <span>{c.title}</span>
              <small>{c.tools.length} INSTRUMENTS</small>
            </button>
          ))}
        </div>
        <p className="armory__inscription" data-reveal>{active.inscription}</p>
        <div className="armory__split">
          <div className="armory__tools" data-reveal>
            {active.tools.map((t) => (
              <button
                key={t.name}
                className={`tool${selected.name === t.name ? ' is-active' : ''}`}
                onClick={() => setTool(t.name)}
                aria-pressed={selected.name === t.name}
              >
                <span className="tool__name">{t.name}</span>
                <span className="tool__tick" aria-hidden="true" />
              </button>
            ))}
          </div>
          <article className="inspect" aria-live="polite" data-reveal>
            <p className="inspect__file">INSPECTION · {active.title}</p>
            <h3>{selected.name}</h3>
            <dl>
              <div><dt>EARNED IN</dt><dd>{selected.context}</dd></div>
              <div><dt>DEPLOYED FOR</dt><dd>{selected.use}</dd></div>
              <div><dt>FIELD RECORD</dt><dd>{selected.linked.join('  ·  ')}</dd></div>
            </dl>
            <a className="inspect__link" href="#forge">See it in the Forge →</a>
          </article>
        </div>
      </div>
    </section>
  );
}
