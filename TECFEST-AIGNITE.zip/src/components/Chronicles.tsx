import SectionHeading from './SectionHeading';
import { chronicles } from '../data/chronicles';

export default function Chronicles() {
  return (
    <section id="chronicles" className="chamber chamber--deep" aria-label="The chronicles — education and journey">
      <div className="container">
        <SectionHeading
          index="05"
          gate="THE CHRONICLES"
          title="Records kept in stone"
          sub="Education and milestones, inscribed as fortress history. Verifiable, dated, unexaggerated."
        />
        <ol className="chronicle">
          {chronicles.map((c) => (
            <li key={c.record} className="chronicle__entry" data-reveal>
              <span className="chronicle__node" aria-hidden="true" />
              <div className="chronicle__card">
                <p className="chronicle__year">{c.year}</p>
                <p className="chronicle__hall">{c.hall}</p>
                <h3>{c.record}</h3>
                <p>{c.detail}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
