import { useEffect, useState } from 'react';

const LINKS = [
  { n: '01', label: 'GATE', href: '#gate' },
  { n: '02', label: 'ARCHITECT', href: '#architect' },
  { n: '03', label: 'ARMORY', href: '#armory' },
  { n: '04', label: 'FORGE', href: '#forge' },
  { n: '05', label: 'CHRONICLES', href: '#chronicles' },
  { n: '06', label: 'ARCHIVE', href: '#archive' },
  { n: '07', label: 'CONTACT', href: '#contact' },
];

export default function FortressNav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('#gate');
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
      const ids = LINKS.map((l) => l.href);
      let current = ids[0];
      for (const id of ids) {
        const el = document.querySelector(id);
        if (el) {
          const r = el.getBoundingClientRect();
          if (r.top <= window.innerHeight * 0.4) current = id;
        }
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open ]);

  return (
    <header className={`fortnav${scrolled ? ' is-scrolled' : ''}`}>
      <a className="fortnav__brand" href="#gate" aria-label="Avinash K — back to the gate">
        <span className="fortnav__sigil" aria-hidden="true">
          <svg viewBox="0 0 32 32" width="26" height="26"><path d="M16 3 L19 8 L24 8 L24 13 L27 14 L27 29 L5 29 L5 14 L8 13 L8 8 L13 8 Z" fill="none" stroke="#35d07f" strokeWidth="2" strokeLinejoin="round"/><circle cx="16" cy="20" r="3.4" fill="none" stroke="#c8b06a" strokeWidth="1.6"/><circle cx="16" cy="20" r="1.2" fill="#35d07f"/></svg>
        </span>
        <span className="fortnav__word">
          <strong>AVK <span>//</span> ARCHIVE</strong>
          <small>FORTRESS CONTROL</small>
        </span>
      </a>
      <nav className="fortnav__links" aria-label="Fortress sections">
        {LINKS.map((l) => (
          <a key={l.href} href={l.href} className={active === l.href ? 'is-active' : ''} aria-current={active === l.href ? 'true' : undefined}>
            <em>{l.n}</em> {l.label}
          </a>
        ))}
      </nav>
      <div className="fortnav__right">
        <span className="fortnav__status" role="status"><i /> SYSTEMS NOMINAL</span>
        <a className="fortnav__cta" href="#contact">TRANSMIT</a>
        <button className="fortnav__burger" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? 'Close fortress menu' : 'Open fortress menu'}>
          <span /><span /><span />
        </button>
      </div>
      <div className={`fortnav__drawer${open ? ' is-open' : ''}`}>
        {LINKS.map((l) => (
          <a key={l.href} href={l.href} onClick={() => setOpen(false)} className={active === l.href ? 'is-active' : ''}>
            <em>{l.n}</em> {l.label}
          </a>
        ))}
        <p className="fortnav__drawer-foot">AVINASH K · SRM VALLIAMMAI · CHENNAI<br />github.com/avinashk08408</p>
      </div>
    </header>
  );
}
