import SectionHeading from './SectionHeading';
import { archiveRecords } from '../data/chronicles';

const ID_FILE = `AVK // IDENTIFICATION FILE
--------------------------
NAME: Avinash K
ROLE: Cyber Security Student & Web Developer
COLLEGE: SRM Valliammai Engineering College, Chennai
PROGRAM: B.E. Cyber Security (2025 - Present)
GITHUB: github.com/avinashk08408

TECHNICAL AREAS
- Web Engineering: HTML, CSS, JavaScript, React
- Development: Python, C, C++, Java, Go, SQL, Git/GitHub
- Security: Linux, Networking, OWASP, Burp Suite, Nmap, Web Security

FORGE RECORDS
1. AuthShield - hardened auth + monitoring
2. Web Vulnerability Scanner - authorized-target audits
3. Shock P&L Engine - portfolio stress testing
4. Weather Forecast CLI - terminal forecast tool
5. PQC Dynamic Proxy Engine - post-quantum concept

STATUS: BUILDING. VERIFY AT github.com/avinashk08408`;

export default function Archive() {
  const download = () => {
    const blob = new Blob([ID_FILE], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AVINASH_K_IDENTIFICATION_FILE.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section id="archive" className="chamber" aria-label="The archive — certifications and resume">
      <div className="container archive__grid">
        <div>
          <SectionHeading
            index="06"
            gate="THE ARCHIVE"
            title="Sealed records & credentials"
            sub="Only real records live here. Anything pending is marked pending — the fortress does not forge seals."
          />
          <div className="archive__stack">
            {archiveRecords.map((r) => (
              <article key={r.name} className="plate" data-reveal>
                <div className="plate__head">
                  <h3>{r.name}</h3>
                  <span className="plate__status">{r.status}</span>
                </div>
                <dl>
                  <div><dt>ISSUER</dt><dd>{r.issuer}</dd></div>
                  <div><dt>DATE</dt><dd>{r.date}</dd></div>
                </dl>
                <p>{r.note}</p>
                {r.link && <a href={r.link} target="_blank" rel="noreferrer">VERIFY ↗</a>}
              </article>
            ))}
          </div>
        </div>
        <aside className="idfile" data-reveal aria-label="Identification file — resume">
          <p className="idfile__label">IDENTIFICATION FILE · AVK-001</p>
          <h3>Avinash K</h3>
          <p className="idfile__role">Cyber Security Student × Web Developer</p>
          <dl>
            <div><dt>EDUCATION</dt><dd>SRM Valliammai, B.E. Cyber Security</dd></div>
            <div><dt>AREAS</dt><dd>Secure web · Python systems · Lab security</dd></div>
            <div><dt>PROOF</dt><dd>5 forge records · GitHub upkeep</dd></div>
          </dl>
          <pre className="idfile__preview">{ID_FILE.split('\n').slice(0, 9).join('\n')}\n…</pre>
          <div className="idfile__actions">
            <button className="btn-iron primary" onClick={download}><span>DOWNLOAD RESUME FILE</span></button>
            <a className="btn-iron" href="https://github.com/avinashk08408" target="_blank" rel="noreferrer"><span>GITHUB RECORD</span></a>
          </div>
          <p className="idfile__note">Plain-text identification file. A designed PDF resume can replace this record without changing the seal.</p>
        </aside>
      </div>
    </section>
  );
}
