import { useEffect } from 'react';
import FortressNav from './components/FortressNav';
import Loader from './components/Loader';
import Gate from './components/Gate';
import Architect from './components/Architect';
import Armory from './components/Armory';
import Forge from './components/Forge';
import Chronicles from './components/Chronicles';
import Archive from './components/Archive';
import Contact from './components/Contact';
import Footer from './components/Footer';
import FortressCanvas from './three/FortressCanvas';
import { useRevealRoot } from './hooks/useFortress';
import { inscribeConsole } from './utils/easter';
import './index.css';

export default function App() {
  const ref = useRevealRoot<HTMLDivElement>();

  useEffect(() => {
    inscribeConsole();
  }, []);

  return (
    <div ref={ref} className="fortress">
      <a className="skip" href="#architect">Skip the gate — go to content</a>
      <Loader />
      <FortressCanvas />
      <FortressNav />
      <main>
        <Gate />
        <div className="wings">
          <Architect />
          <Armory />
          <Forge />
          <Chronicles />
          <Archive />
          <Contact />
        </div>
      </main>
      <Footer />
    </div>
  );
}
